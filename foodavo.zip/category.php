<?php

require_once 'connection.php';

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.0.0-dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <title>Foodavo</title>
</head>

<body>

    <nav class="navbar navbar-light bg-light" style="height: 80px;">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <button type="button" class="btn btn-default" aria-label="Left Align">
                    <svg class="icon line" width="24" height="24" id="menu" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <line x1="9" y1="18" x2="21" y2="18" style="fill: none; stroke: rgb(0, 0, 0); stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;"></line>
                        <line x1="3" y1="12" x2="21" y2="12" style="fill: none; stroke: rgb(0, 0, 0); stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;"></line>
                        <line x1="3" y1="6" x2="15" y2="6" style="fill: none; stroke: rgb(0, 0, 0); stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;"></line>
                    </svg>
                </button>
                <img src="images/logo.jpeg" alt="" height="50">
            </a>
            <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            </form>
        </div>
    </nav>



    <div class="container-fluid">
        <div class="row">
            <h4 class="mt-5">
                <b>
                    <?php if ($_GET['id'] == 1) {
                        echo 'Restaurant';
                    } elseif ($_GET['id'] == 2) {
                        echo 'Bar';
                    } else {
                        echo 'Cafe';
                    } ?>
                    List</b>
            </h4>
            <div class="row row-cols-1 row-cols-md-3 g-4">


                <?php
                $id = $_GET['id'];
                $get = $conn->query("SELECT * FROM restaurant WHERE id_category = {$id}");
                while ($data = mysqli_fetch_assoc($get)) {
                ?>



                    <div class="col-lg-3">
                        <div class="card h-100">
                            <img src="images/<?= $data['image']; ?>" card-img-top" alt="..." class="w-100 img-fluid">
                            <div class="position-relative">
                                <p class="position-absolute top-0 end-0 card-text btn btn-warning emd" style="font-size: 10pt;">
                                    <?php if ($data['id_category'] == 1) {
                                        echo 'Restaurant';
                                    } elseif ($data['id_category'] == 2) {
                                        echo 'Bar';
                                    } else {
                                        echo 'Cafe';
                                    } ?>
                                </p>
                            </div>
                            <div class="card-body">
                                <h5 class="card-title"><?= $data["name"]; ?></h5>
                                <br>
                                <p class="card-text"><b>Price Range</b> : <?= $data['price_range']; ?><br><b>Address</b> : <?= $data['address']; ?></p>
                            </div>
                            <div class="card-footer">
                                <a href="detail.php?id=<?= $data['id_restaurant']; ?>" class="btn btn-primary" style="width: 100%;">Detail</a>
                            </div>
                        </div>
                    </div>

                <?php
                }
                ?>

            </div>
        </div>
    </div>

    <script src="bootstrap-5.0.0-dist/js/bootstrap.bundle.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</body>

</html>