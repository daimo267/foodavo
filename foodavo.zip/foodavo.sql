-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 31, 2021 at 05:13 AM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 7.3.27

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodavo`
--

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `id_category` int(11) NOT NULL,
  `name` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id_category`, `name`) VALUES
(1, 'restaurant'),
(2, 'bar'),
(3, 'cafe');

-- --------------------------------------------------------

--
-- Table structure for table `comments`
--

CREATE TABLE `comments` (
  `id_comments` int(11) NOT NULL,
  `field` varchar(100) NOT NULL,
  `rate` int(11) NOT NULL,
  `id_restaurant` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `ratings`
--

CREATE TABLE `ratings` (
  `id_ratings` int(11) NOT NULL,
  `rate` int(11) NOT NULL,
  `id_restaurant` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `restaurant`
--

CREATE TABLE `restaurant` (
  `id_restaurant` int(11) NOT NULL,
  `name` varchar(11) NOT NULL,
  `address` text NOT NULL,
  `zomato_url` varchar(100) NOT NULL,
  `traveloka_url` varchar(100) NOT NULL,
  `open_hours` varchar(30) NOT NULL,
  `food_category` varchar(11) NOT NULL,
  `price_range` varchar(30) NOT NULL,
  `phone` varchar(14) NOT NULL,
  `facilities` varchar(100) NOT NULL,
  `image` varchar(100) NOT NULL,
  `id_category` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `restaurant`
--

INSERT INTO `restaurant` (`id_restaurant`, `name`, `address`, `zomato_url`, `traveloka_url`, `open_hours`, `food_category`, `price_range`, `phone`, `facilities`, `image`, `id_category`) VALUES
(6, 'Kubu ', 'ubud, bali', 'https://www.zomato.com/bali/kubu-at-mandapa-1-ubud', 'https://www.traveloka.com/id-id/restaurants/indonesia/detail/Kubu-at-Mandapa-57022', '09.00 - 20.00', 'fine dining', '704000–1056000', '082100155990', 'reserved seating in open areas, parking lots, wheelchair access, full bar, serving alk', 'kubu.jpg', 1),
(7, ' Caswell\'s ', 'Jl. RS. Fatmawati Raya No.15A, RT.1/RW.3, Gandaria Sel., Kec. Cilandak, Kota Jakarta Selatan, Daerah Khusus Ibukota Jakarta 12420', 'https://www.zomato.com/jakarta/caswells-cilandak', '-', '09.00 - 20.00', 'cafetaria', '18000 - 100000', '0217502025', 'reserved seating in open areas, parking lots, wheelchair access, full bar, serving alk', 'caswell.jpg', 3),
(8, 'B.A.T.S.', 'Shangri-La Hotel Jakarta Level 1, Jl. Jend. Sudirman No.Kav. 1, RT.10/RW.9, Karet Tengsin, Tanah Abang, Central Jakarta City, Jakarta 10220', 'https://www.zomato.com/jakarta/b-a-t-s-shangri-la-hotel-sudirman', 'https://www.traveloka.com/id-id/restaurants/indonesia/detail/bats-41211', '18.00 - 02.00', 'pub grub', '80000 - 300000', '02129229999', 'Roomy, dark tavern for cocktails, American grub & live music at the Shangri-La Hotel Jakarta.', 'bats.jpg', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`id_category`);

--
-- Indexes for table `comments`
--
ALTER TABLE `comments`
  ADD PRIMARY KEY (`id_comments`),
  ADD KEY `id_restaurant` (`id_restaurant`);

--
-- Indexes for table `ratings`
--
ALTER TABLE `ratings`
  ADD PRIMARY KEY (`id_ratings`),
  ADD KEY `id_restaurant` (`id_restaurant`);

--
-- Indexes for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD PRIMARY KEY (`id_restaurant`),
  ADD KEY `id_category` (`id_category`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `category`
--
ALTER TABLE `category`
  MODIFY `id_category` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `comments`
--
ALTER TABLE `comments`
  MODIFY `id_comments` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ratings`
--
ALTER TABLE `ratings`
  MODIFY `id_ratings` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `restaurant`
--
ALTER TABLE `restaurant`
  MODIFY `id_restaurant` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comments`
--
ALTER TABLE `comments`
  ADD CONSTRAINT `comments_ibfk_1` FOREIGN KEY (`id_restaurant`) REFERENCES `restaurant` (`id_restaurant`);

--
-- Constraints for table `ratings`
--
ALTER TABLE `ratings`
  ADD CONSTRAINT `ratings_ibfk_1` FOREIGN KEY (`id_restaurant`) REFERENCES `restaurant` (`id_restaurant`);

--
-- Constraints for table `restaurant`
--
ALTER TABLE `restaurant`
  ADD CONSTRAINT `restaurant_ibfk_1` FOREIGN KEY (`id_category`) REFERENCES `category` (`id_category`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
