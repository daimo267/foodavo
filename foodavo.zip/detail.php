<?php

require_once 'connection.php';
function stars($from, $ratingFrom){
    $stars = "";
    if ($ratingFrom == '-'){
        $stars .= "Not yet reviews in {$from}";
    }else{
        if ($ratingFrom >= 1 && $ratingFrom < 2){
            $stars .= "⭐";
        }
        if ($ratingFrom >= 2 && $ratingFrom < 3){
            $stars .= "⭐⭐";
        }
        if ($ratingFrom >= 3 && $ratingFrom < 4){
            $stars .= "⭐⭐⭐";
        }
        if ($ratingFrom >= 4 && $ratingFrom < 5){
            $stars .= "⭐⭐⭐⭐";
        }
        if ($ratingFrom >= 5 && $ratingFrom < 6){
            $stars .= "⭐⭐⭐⭐⭐";
        }
    }
    return $stars;
}
function curl ($url, $post = 0, $httpheader = 0, $proxy = 0, $uagent = 0){ // url, postdata, http headers, proxy, uagent
    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    curl_setopt($ch, CURLOPT_FOLLOWLOCATION, true);
    curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
    curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
    curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
    curl_setopt($ch, CURLOPT_TIMEOUT, 60);
    if($post){
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $post);
    }
    if($httpheader){
        curl_setopt($ch, CURLOPT_HTTPHEADER, $httpheader);
    }
    if($proxy){
        curl_setopt($ch, CURLOPT_HTTPPROXYTUNNEL, true);
        curl_setopt($ch, CURLOPT_PROXY, $proxy);
        // curl_setopt($ch, CURLOPT_PROXYTYPE, CURLPROXY_SOCKS5);
    }
    if($uagent){
        curl_setopt($ch, CURLOPT_USERAGENT, $uagent);
    }else{
        curl_setopt($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:66.0) Gecko/20100101 Firefox/".rand(1,200).".0");
    }
    curl_setopt($ch, CURLOPT_HEADER, true);
    $response = curl_exec($ch);
    $httpcode = curl_getinfo($ch);
    if(!$httpcode) return "Curl Error : ".curl_error($ch); else{
        $header = substr($response, 0, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
        $body = substr($response, curl_getinfo($ch, CURLINFO_HEADER_SIZE));
        curl_close($ch);
        return array($header, $body);
    }
}
?>


<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="bootstrap-5.0.0-dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-wEmeIV1mKuiNpC+IOBjI7aAzPcEZeedi5yW5f2yOq55WWLwNGmvvx4Um1vskeMj0" crossorigin="anonymous">
    <title>Foodavo</title>
</head>

<body>

    <nav class="navbar navbar-light bg-light" style="height: 80px;">
        <div class="container-fluid">
            <a class="navbar-brand" href="index.php">
                <button type="button" class="btn btn-default" aria-label="Left Align">
                    <svg class="icon line" width="24" height="24" id="menu" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                        <line x1="9" y1="18" x2="21" y2="18" style="fill: none; stroke: rgb(0, 0, 0); stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;"></line>
                        <line x1="3" y1="12" x2="21" y2="12" style="fill: none; stroke: rgb(0, 0, 0); stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;"></line>
                        <line x1="3" y1="6" x2="15" y2="6" style="fill: none; stroke: rgb(0, 0, 0); stroke-linecap: round; stroke-linejoin: round; stroke-width: 2;"></line>
                    </svg>
                </button>
                <img src="images/logo.jpeg" alt="" height="50">
            </a>
            <form class="d-flex">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
            </form>
        </div>
    </nav>


    <?php
    $id = $_GET['id'];
    $get = $conn->query("SELECT * FROM restaurant WHERE id_restaurant = {$id} ");
    $data = mysqli_fetch_assoc($get);
    $headers_traveloka = array();
    $headers_traveloka[] = 'Authority: www.traveloka.com';
    $headers_traveloka[] = 'Cache-Control: max-age=0';
    $headers_traveloka[] = 'Sec-Ch-Ua: ^^';
    $headers_traveloka[] = 'Sec-Ch-Ua-Mobile: ?0';
    $headers_traveloka[] = 'Upgrade-Insecure-Requests: 1';
    $headers_traveloka[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36';
    $headers_traveloka[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
    $headers_traveloka[] = 'Sec-Fetch-Site: none';
    $headers_traveloka[] = 'Sec-Fetch-Mode: navigate';
    $headers_traveloka[] = 'Sec-Fetch-User: ?1';
    $headers_traveloka[] = 'Sec-Fetch-Dest: document';
    $headers_traveloka[] = 'Accept-Language: en-US,en;q=0.9,id;q=0.8';
    $headers_zomato = array();
    $headers_zomato[] = 'Authority: www.zomato.com';
    $headers_zomato[] = 'Cache-Control: max-age=0';
    $headers_zomato[] = 'Sec-Ch-Ua: ^^';
    $headers_zomato[] = 'Sec-Ch-Ua-Mobile: ?0';
    $headers_zomato[] = 'Upgrade-Insecure-Requests: 1';
    $headers_zomato[] = 'User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36';
    $headers_zomato[] = 'Accept: text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9';
    $headers_zomato[] = 'Sec-Fetch-Site: same-origin';
    $headers_zomato[] = 'Sec-Fetch-Mode: navigate';
    $headers_zomato[] = 'Sec-Fetch-User: ?1';
    $headers_zomato[] = 'Sec-Fetch-Dest: document';
    $headers_zomato[] = 'Referer: https://www.zomato.com/jakarta/b-a-t-s-shangri-la-hotel-sudirman';
    $headers_zomato[] = 'Accept-Language: en-US,en;q=0.9,id;q=0.8';
    $get_rating_zomato = curl($data['zomato_url'], 0, $headers_zomato)[1];
    if ($data['zomato_url'] !== "-" && preg_match('#"ratingValue":"(.*?)"#si', $get_rating_zomato, $zomato_rating)){
       $zomato_rating = $zomato_rating[1];
    }else{
        $zomato_rating = '-';
    }
    $get_rating_traveloka = curl($data['traveloka_url'], 0, $headers_traveloka)[1];
    if ($data['traveloka_url'] !== "-" && preg_match('#"ratingValue":(.*?),#si', $get_rating_traveloka, $traveloka_rating)){
        $traveloka_rating = $traveloka_rating[1];
     }else{
        $traveloka_rating = '-';
     }
    ?>


    <div class="container-fluid">
        <div class="row">
            <div class="col-lg-5 card my-3"">
                <h4><b><?= $data['name']; ?>
                    </b></h4>
                <P><?php if ($data['id_category'] == 1) {
                        echo 'Restaurant';
                    } elseif ($data['id_category'] == 2) {
                        echo 'Bar';
                    } else {
                        echo 'Cafe';
                    } ?>
                </P>
                <div class=" col-lg-12">
            </div>
            <div class="col-lg-12">
                <img src="images/<?= $data['image']; ?>" class="card-img-top w-100   img-fluid" alt="...">
            </div>
            <br>
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-2 mx-2">
                        <img src="images/<?= $data['image']; ?>" class="card-img-top w-100   img-fluid" alt="...">
                    </div>
                    <div class="col-lg-2 mx-2">
                        <img src="images/<?= $data['image']; ?>" class="card-img-top w-100   img-fluid" alt="...">
                    </div>
                    <div class="col-lg-2 mx-2">
                        <img src="images/<?= $data['image']; ?>" class="card-img-top w-100   img-fluid" alt="...">
                    </div>
                    <div class="col-lg-2 mx-2">
                        <img src="images/<?= $data['image']; ?>" class="card-img-top w-100   img-fluid" alt="...">
                    </div>
                    <div class="col-lg-2 mx-2">
                        <img src="images/<?= $data['image']; ?>" class="card-img-top w-100   img-fluid" alt="...">
                    </div>
                </div>
            </div>
        </div>
        <div class="col-lg-4">
            <h4><b>Restaurant Description</b></h4>
            <div class="col-lg-12 my-5">
                <h5>Opening Hours</h5>
                <p><?= $data['open_hours']; ?>
                </p>
            </div>
            <div class="col-lg-12 my-5">
                <h5>Food Category</h5>
                <p><?= $data['food_category']; ?>
                </p>
            </div>
            <div class="col-lg-12 my-5">
                <h5>Price Range</h5>
                <p><?= $data['price_range']; ?>
                </p>
            </div>
            <div class="col-lg-12 my-5">
                <h5>Phone Number</h5>
                <p><?= $data['phone']; ?>
                </p>
            </div>
            <div class="col-lg-12 my-5">
                <h5>Full Address</h5>
                <div class="row">
                    <div class="col-lg-9">
                        <p><?= $data['address']; ?>
                    </div>
                    <div class="col-lg">
                        <img src="images/maps.png" class="img-fluid" alt="">
                    </div>
                </div>
                </p>
            </div>
            <div class="col-lg-12 my-5">
                <h5>Facilities</h5>
                <p><?= $data['facilities']; ?>
                </p>
            </div>
        </div>
        <div class="col-lg-3" style="height: 90vh; overflow-y: scroll;">
            <h4><b>Ratings and Comment</b></h4>
            <div class="col-lg-12 card my-3 px-2">
                <div class="row">
                    <div class="col-lg-3 m-auto">
                    <a href="<?php echo $data['traveloka_url']; ?>" target="_blank"><img src="images/traveloka.png" class="img-fluid" style="width: 50px;" alt=""></a>
                    </div>
                    <div class="col-lg-9 pt-3">
                        <p><b><?php echo stars('traveloka', $traveloka_rating); ?></b><br><?php echo $traveloka_rating; ?>/5</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 card my-3 px-2">
                <div class="row">
                    <div class="col-lg-3 m-auto">
                        <a href="<?php echo $data['zomato_url']; ?>" target="_blank"><img src="images/zomato-logo.png" class="img-fluid" style="width: 50px;" alt=""></a>
                    </div>
                    <div class="col-lg-9 pt-3">
                        <?php 
                            
                        ?>
                        <p><b><?php echo stars('zomato', $zomato_rating); ?></b><br><?php echo $zomato_rating; ?>/5</p>
                    </div>
                </div>
            </div>

            <div class="col-lg-12 card my-3 px-2">
                <div class="row">
                    <div class="col-lg-3 m-auto">
                        <img src="images/user.svg" class="img-fluid" style="width: 50px;" alt="">
                    </div>
                    <div class="col-lg-9 pt-3">
                        <p><b>⭐⭐⭐⭐⭐</b><br>5/5</p>
                    </div>
                    <p><b>comments :</b><br>Love Le Quartier very much. Not too crowded during this pandemic but the quality of the food is still great</p>
                </div>
            </div>

            <div class="col-lg-12 card my-3 px-2">
                <div class="row">
                    <div class="col-lg-3 m-auto">
                        <img src="images/user.svg" class="img-fluid" style="width: 50px;" alt="">
                    </div>
                    <div class="col-lg-9 pt-3">
                        <p><b>⭐⭐⭐⭐⭐</b><br>5/5</p>
                    </div>
                    <p><b>comments :</b><br>Not my food type.. but the taste still good 👍👍
                        Even though overpricey for the breakfast 😉
                    </p>
                </div>
            </div>

            <div class="col-lg-12 card my-3 px-2">
                <div class="row">
                    <div class="col-lg-3 m-auto">
                        <img src="images/user.svg" class="img-fluid" style="width: 50px;" alt="">
                    </div>
                    <div class="col-lg-9 pt-3">
                        <p><b>⭐⭐⭐⭐⭐</b><br>5/5</p>
                    </div>
                    <p><b>comments :</b><br>i love this place</p>
                </div>
            </div>

        </div>
    </div>
    </div>

    <script src="bootstrap-5.0.0-dist/js/bootstrap.min.js" integrity="sha384-p34f1UUtsS3wqzfto5wAAmdvj+osOnFyQFpp4Ua3gs/ZVWx6oOypYoCJhGGScy+8" crossorigin="anonymous"></script>
</body>

</html>